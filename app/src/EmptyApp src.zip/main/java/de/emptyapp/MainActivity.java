package de.emptyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button button1;
    private Button button2;
    private Button button3;
    private EditText editText1;
    private EditText editTextPassword;
    private TextView textView2;
    private TextView textView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        editText1 = (EditText) findViewById(R.id.editText1);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);
        textView2 = (TextView) findViewById(R.id.textView2);
        textView3 = (TextView) findViewById(R.id.textView3);

        this.button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText("test");
                Toast.makeText(view.getContext(), "Button1 gedrückt", Toast.LENGTH_SHORT).show();
            }
        });

        this.button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView2.setText(editText1.getText());
                Toast.makeText(view.getContext(), "Button2 gedrückt", Toast.LENGTH_SHORT).show();
            }
        });

        this.button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView3.setText(editTextPassword.getText());
                Toast.makeText(view.getContext(), "Button3 gedrückt", Toast.LENGTH_SHORT).show();
            }
        });


    }
}